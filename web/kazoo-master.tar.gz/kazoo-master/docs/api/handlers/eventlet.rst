.. _eventlet_handler_module:

:mod:`kazoo.handlers.eventlet`
----------------------------

.. automodule:: kazoo.handlers.eventlet

Public API
++++++++++

    .. autoclass:: SequentialEventletHandler
        :members:

Private API
+++++++++++

  .. autoclass:: AsyncResult
     :members:
