.. _gevent_handler_module:

:mod:`kazoo.handlers.gevent`
----------------------------

.. automodule:: kazoo.handlers.gevent

Public API
++++++++++

    .. autoclass:: SequentialGeventHandler
        :members:

Private API
+++++++++++

  .. autoclass:: AsyncResult
     :members:
